"""Common shared package."""
